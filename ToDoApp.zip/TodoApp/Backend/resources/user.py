from flask_restful import Resource

class user(Resource):
    def get(self):
        username="himayaperera"
        password="Zeal"
        return {"message": "Hello, Username: "+username+" Password: "+password}

