from flask_restful import Resource

class hello(Resource):
    def get(self):
        username="himayaperera"
        password="ZealOcellus"
        return {"message": "Hello smol wun"}